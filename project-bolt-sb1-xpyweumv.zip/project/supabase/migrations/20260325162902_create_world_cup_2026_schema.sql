/*
  # Create World Cup 2026 Database Schema

  1. New Tables
    - `teams`
      - `id` (uuid, primary key)
      - `name` (text) - Team name in English
      - `name_ar` (text) - Team name in Arabic
      - `flag_url` (text) - URL to team flag image
      - `group_name` (text) - Group letter (A, B, C, etc.)
      - `played` (integer) - Matches played
      - `won` (integer) - Matches won
      - `drawn` (integer) - Matches drawn
      - `lost` (integer) - Matches lost
      - `goals_for` (integer) - Goals scored
      - `goals_against` (integer) - Goals conceded
      - `goal_difference` (integer) - Goal difference
      - `points` (integer) - Total points
      - `created_at` (timestamp)
      
    - `matches`
      - `id` (uuid, primary key)
      - `home_team_id` (uuid, foreign key to teams)
      - `away_team_id` (uuid, foreign key to teams)
      - `home_score` (integer) - Home team score
      - `away_score` (integer) - Away team score
      - `match_date` (timestamp) - Date and time of match
      - `venue` (text) - Stadium name
      - `venue_ar` (text) - Stadium name in Arabic
      - `status` (text) - Match status: scheduled, live, finished
      - `group_name` (text) - Group letter for group stage matches
      - `stage` (text) - Tournament stage: group, round16, quarter, semi, final
      - `created_at` (timestamp)
      
    - `news`
      - `id` (uuid, primary key)
      - `title` (text) - News title in English
      - `title_ar` (text) - News title in Arabic
      - `content` (text) - News content in English
      - `content_ar` (text) - News content in Arabic
      - `image_url` (text) - News image URL
      - `published_at` (timestamp) - Publication date
      - `created_at` (timestamp)
      
    - `players`
      - `id` (uuid, primary key)
      - `name` (text) - Player name in English
      - `name_ar` (text) - Player name in Arabic
      - `team_id` (uuid, foreign key to teams)
      - `position` (text) - Player position
      - `position_ar` (text) - Player position in Arabic
      - `photo_url` (text) - Player photo URL
      - `age` (integer) - Player age
      - `is_star` (boolean) - Featured star player
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for public read access (World Cup data is public)
    - Restrict write operations to authenticated users only
*/

-- Create teams table
CREATE TABLE IF NOT EXISTS teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_ar text NOT NULL,
  flag_url text DEFAULT '',
  group_name text NOT NULL,
  played integer DEFAULT 0,
  won integer DEFAULT 0,
  drawn integer DEFAULT 0,
  lost integer DEFAULT 0,
  goals_for integer DEFAULT 0,
  goals_against integer DEFAULT 0,
  goal_difference integer DEFAULT 0,
  points integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create matches table
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  home_team_id uuid REFERENCES teams(id) ON DELETE CASCADE,
  away_team_id uuid REFERENCES teams(id) ON DELETE CASCADE,
  home_score integer DEFAULT 0,
  away_score integer DEFAULT 0,
  match_date timestamptz NOT NULL,
  venue text DEFAULT '',
  venue_ar text DEFAULT '',
  status text DEFAULT 'scheduled',
  group_name text DEFAULT '',
  stage text DEFAULT 'group',
  created_at timestamptz DEFAULT now()
);

-- Create news table
CREATE TABLE IF NOT EXISTS news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  title_ar text NOT NULL,
  content text NOT NULL,
  content_ar text NOT NULL,
  image_url text DEFAULT '',
  published_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Create players table
CREATE TABLE IF NOT EXISTS players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_ar text NOT NULL,
  team_id uuid REFERENCES teams(id) ON DELETE CASCADE,
  position text NOT NULL,
  position_ar text NOT NULL,
  photo_url text DEFAULT '',
  age integer NOT NULL,
  is_star boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE news ENABLE ROW LEVEL SECURITY;
ALTER TABLE players ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access
CREATE POLICY "Anyone can view teams"
  ON teams FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view matches"
  ON matches FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view news"
  ON news FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view players"
  ON players FOR SELECT
  TO public
  USING (true);

-- Create policies for authenticated users to manage data
CREATE POLICY "Authenticated users can insert teams"
  ON teams FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update teams"
  ON teams FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete teams"
  ON teams FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert matches"
  ON matches FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update matches"
  ON matches FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete matches"
  ON matches FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert news"
  ON news FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update news"
  ON news FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete news"
  ON news FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert players"
  ON players FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update players"
  ON players FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete players"
  ON players FOR DELETE
  TO authenticated
  USING (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_teams_group ON teams(group_name);
CREATE INDEX IF NOT EXISTS idx_matches_date ON matches(match_date);
CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);
CREATE INDEX IF NOT EXISTS idx_news_published ON news(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_players_star ON players(is_star) WHERE is_star = true;