import { useEffect, useState } from 'react';
import { supabase, Team } from '../lib/supabase';
import { TrendingUp } from 'lucide-react';

export default function GroupStandings() {
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGroup, setSelectedGroup] = useState('A');

  const groups = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'];

  useEffect(() => {
    fetchTeams();
  }, []);

  async function fetchTeams() {
    try {
      const { data, error } = await supabase
        .from('teams')
        .select('*')
        .order('group_name', { ascending: true })
        .order('points', { ascending: false })
        .order('goal_difference', { ascending: false });

      if (error) throw error;
      setTeams(data || []);
    } catch (error) {
      console.error('Error fetching teams:', error);
    } finally {
      setLoading(false);
    }
  }

  const filteredTeams = teams.filter(team => team.group_name === selectedGroup);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <TrendingUp className="w-8 h-8 text-blue-600" />
        <h2 className="text-3xl font-bold text-gray-800">ترتيب المجموعات</h2>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-4">
        {groups.map((group) => (
          <button
            key={group}
            onClick={() => setSelectedGroup(group)}
            className={`px-4 py-2 rounded-lg font-semibold transition-all whitespace-nowrap ${
              selectedGroup === group
                ? 'bg-blue-600 text-white shadow-lg'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            المجموعة {group}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4">
          <h3 className="text-2xl font-bold">المجموعة {selectedGroup}</h3>
        </div>

        {filteredTeams.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            لا توجد فرق في هذه المجموعة حالياً
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-gray-700">#</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-gray-700">الفريق</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">لعب</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">فاز</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">تعادل</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">خسر</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">له</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">عليه</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700">الفارق</th>
                  <th className="px-6 py-4 text-center text-sm font-semibold text-gray-700 bg-blue-50">النقاط</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredTeams.map((team, index) => (
                  <tr
                    key={team.id}
                    className={`hover:bg-blue-50 transition-colors ${
                      index < 2 ? 'bg-green-50' : ''
                    }`}
                  >
                    <td className="px-6 py-4 text-gray-700 font-semibold">{index + 1}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        {team.flag_url && (
                          <img
                            src={team.flag_url}
                            alt={team.name_ar}
                            className="w-8 h-6 object-cover rounded shadow"
                          />
                        )}
                        <span className="font-semibold text-gray-800">{team.name_ar}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center text-gray-700">{team.played}</td>
                    <td className="px-6 py-4 text-center text-green-600 font-semibold">{team.won}</td>
                    <td className="px-6 py-4 text-center text-gray-600">{team.drawn}</td>
                    <td className="px-6 py-4 text-center text-red-600 font-semibold">{team.lost}</td>
                    <td className="px-6 py-4 text-center text-gray-700">{team.goals_for}</td>
                    <td className="px-6 py-4 text-center text-gray-700">{team.goals_against}</td>
                    <td className={`px-6 py-4 text-center font-semibold ${
                      team.goal_difference > 0 ? 'text-green-600' :
                      team.goal_difference < 0 ? 'text-red-600' : 'text-gray-700'
                    }`}>
                      {team.goal_difference > 0 ? '+' : ''}{team.goal_difference}
                    </td>
                    <td className="px-6 py-4 text-center font-bold text-blue-600 bg-blue-50 text-lg">
                      {team.points}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
          <div className="flex items-center gap-6 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-50 border border-green-200 rounded"></div>
              <span>يتأهل للدور التالي</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
