import { useEffect, useState } from 'react';
import { supabase, Match, Team } from '../lib/supabase';
import { Radio, MapPin } from 'lucide-react';

type MatchWithTeams = Match & {
  home_team: Team;
  away_team: Team;
};

export default function LiveMatches() {
  const [liveMatches, setLiveMatches] = useState<MatchWithTeams[]>([]);
  const [finishedMatches, setFinishedMatches] = useState<MatchWithTeams[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMatches();
    const interval = setInterval(fetchMatches, 30000);
    return () => clearInterval(interval);
  }, []);

  async function fetchMatches() {
    try {
      const { data: liveData, error: liveError } = await supabase
        .from('matches')
        .select('*')
        .eq('status', 'live')
        .order('match_date', { ascending: false });

      const { data: finishedData, error: finishedError } = await supabase
        .from('matches')
        .select('*')
        .eq('status', 'finished')
        .order('match_date', { ascending: false })
        .limit(10);

      if (liveError) throw liveError;
      if (finishedError) throw finishedError;

      const allMatches = [...(liveData || []), ...(finishedData || [])];

      if (allMatches.length > 0) {
        const teamIds = new Set<string>();
        allMatches.forEach(match => {
          teamIds.add(match.home_team_id);
          teamIds.add(match.away_team_id);
        });

        const { data: teamsData, error: teamsError } = await supabase
          .from('teams')
          .select('*')
          .in('id', Array.from(teamIds));

        if (teamsError) throw teamsError;

        const teamsMap = new Map(teamsData?.map(team => [team.id, team]) || []);

        const liveWithTeams = (liveData || []).map(match => ({
          ...match,
          home_team: teamsMap.get(match.home_team_id)!,
          away_team: teamsMap.get(match.away_team_id)!,
        }));

        const finishedWithTeams = (finishedData || []).map(match => ({
          ...match,
          home_team: teamsMap.get(match.home_team_id)!,
          away_team: teamsMap.get(match.away_team_id)!,
        }));

        setLiveMatches(liveWithTeams);
        setFinishedMatches(finishedWithTeams);
      }
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setLoading(false);
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      hour: '2-digit',
      minute: '2-digit',
    };
    return date.toLocaleDateString('ar-SA', options);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-3 mb-6">
        <Radio className="w-8 h-8 text-red-600" />
        <h2 className="text-3xl font-bold text-gray-800">النتائج المباشرة</h2>
      </div>

      {liveMatches.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
            مباريات جارية الآن
          </h3>
          {liveMatches.map((match) => (
            <MatchCard key={match.id} match={match} isLive={true} formatDate={formatDate} />
          ))}
        </div>
      )}

      {finishedMatches.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-2xl font-bold text-gray-800">النتائج السابقة</h3>
          {finishedMatches.map((match) => (
            <MatchCard key={match.id} match={match} isLive={false} formatDate={formatDate} />
          ))}
        </div>
      )}

      {liveMatches.length === 0 && finishedMatches.length === 0 && (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <Radio className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">لا توجد مباريات حالياً</p>
        </div>
      )}
    </div>
  );
}

function MatchCard({
  match,
  isLive,
  formatDate,
}: {
  match: MatchWithTeams;
  isLive: boolean;
  formatDate: (date: string) => string;
}) {
  return (
    <div className={`bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow ${
      isLive ? 'ring-2 ring-red-500' : ''
    }`}>
      <div className={`${
        isLive
          ? 'bg-gradient-to-r from-red-600 to-red-700'
          : 'bg-gradient-to-r from-gray-600 to-gray-700'
      } text-white px-6 py-3`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isLive && (
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
              </span>
            )}
            <span className="font-semibold">
              {isLive ? 'مباشر الآن' : formatDate(match.match_date)}
            </span>
          </div>
          {match.group_name && (
            <span className="bg-white/20 px-3 py-1 rounded-full text-sm font-semibold">
              المجموعة {match.group_name}
            </span>
          )}
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-[1fr,auto,1fr] gap-6 items-center">
          <div className="text-center">
            {match.home_team?.flag_url && (
              <img
                src={match.home_team.flag_url}
                alt={match.home_team.name_ar}
                className="w-20 h-14 object-cover rounded-lg shadow-md mx-auto mb-3"
              />
            )}
            <h3 className="text-lg font-bold text-gray-800 mb-2">
              {match.home_team?.name_ar || 'فريق 1'}
            </h3>
          </div>

          <div className="text-center px-4">
            <div className="flex items-center gap-4">
              <div className={`text-5xl font-bold ${
                isLive ? 'text-red-600' : 'text-gray-800'
              }`}>
                {match.home_score}
              </div>
              <div className="text-2xl font-bold text-gray-400">-</div>
              <div className={`text-5xl font-bold ${
                isLive ? 'text-red-600' : 'text-gray-800'
              }`}>
                {match.away_score}
              </div>
            </div>
            {isLive && (
              <div className="mt-2 text-sm font-semibold text-red-600 animate-pulse">
                مباشر
              </div>
            )}
          </div>

          <div className="text-center">
            {match.away_team?.flag_url && (
              <img
                src={match.away_team.flag_url}
                alt={match.away_team.name_ar}
                className="w-20 h-14 object-cover rounded-lg shadow-md mx-auto mb-3"
              />
            )}
            <h3 className="text-lg font-bold text-gray-800 mb-2">
              {match.away_team?.name_ar || 'فريق 2'}
            </h3>
          </div>
        </div>

        {match.venue_ar && (
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-center gap-2 text-gray-600">
              <MapPin className="w-5 h-5" />
              <span className="font-semibold">{match.venue_ar}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
