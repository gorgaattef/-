import { useEffect, useState } from 'react';
import { supabase, Match, Team } from '../lib/supabase';
import { Calendar, MapPin } from 'lucide-react';

type MatchWithTeams = Match & {
  home_team: Team;
  away_team: Team;
};

export default function UpcomingMatches() {
  const [matches, setMatches] = useState<MatchWithTeams[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMatches();
  }, []);

  async function fetchMatches() {
    try {
      const { data: matchesData, error } = await supabase
        .from('matches')
        .select('*')
        .eq('status', 'scheduled')
        .order('match_date', { ascending: true })
        .limit(20);

      if (error) throw error;

      if (matchesData && matchesData.length > 0) {
        const teamIds = new Set<string>();
        matchesData.forEach(match => {
          teamIds.add(match.home_team_id);
          teamIds.add(match.away_team_id);
        });

        const { data: teamsData, error: teamsError } = await supabase
          .from('teams')
          .select('*')
          .in('id', Array.from(teamIds));

        if (teamsError) throw teamsError;

        const teamsMap = new Map(teamsData?.map(team => [team.id, team]) || []);

        const matchesWithTeams = matchesData.map(match => ({
          ...match,
          home_team: teamsMap.get(match.home_team_id)!,
          away_team: teamsMap.get(match.away_team_id)!,
        }));

        setMatches(matchesWithTeams);
      }
    } catch (error) {
      console.error('Error fetching matches:', error);
    } finally {
      setLoading(false);
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    };
    return date.toLocaleDateString('ar-SA', options);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Calendar className="w-8 h-8 text-blue-600" />
        <h2 className="text-3xl font-bold text-gray-800">المباريات القادمة</h2>
      </div>

      {matches.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">لا توجد مباريات قادمة حالياً</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {matches.map((match) => (
            <div
              key={match.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
            >
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    <span className="font-semibold">{formatDate(match.match_date)}</span>
                  </div>
                  {match.group_name && (
                    <span className="bg-white/20 px-3 py-1 rounded-full text-sm font-semibold">
                      المجموعة {match.group_name}
                    </span>
                  )}
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-[1fr,auto,1fr] gap-6 items-center">
                  <div className="text-center">
                    {match.home_team?.flag_url && (
                      <img
                        src={match.home_team.flag_url}
                        alt={match.home_team.name_ar}
                        className="w-24 h-16 object-cover rounded-lg shadow-md mx-auto mb-3"
                      />
                    )}
                    <h3 className="text-xl font-bold text-gray-800">
                      {match.home_team?.name_ar || 'فريق 1'}
                    </h3>
                  </div>

                  <div className="text-center px-6">
                    <div className="text-4xl font-bold text-gray-400">VS</div>
                  </div>

                  <div className="text-center">
                    {match.away_team?.flag_url && (
                      <img
                        src={match.away_team.flag_url}
                        alt={match.away_team.name_ar}
                        className="w-24 h-16 object-cover rounded-lg shadow-md mx-auto mb-3"
                      />
                    )}
                    <h3 className="text-xl font-bold text-gray-800">
                      {match.away_team?.name_ar || 'فريق 2'}
                    </h3>
                  </div>
                </div>

                {match.venue_ar && (
                  <div className="mt-6 pt-4 border-t border-gray-200">
                    <div className="flex items-center justify-center gap-2 text-gray-600">
                      <MapPin className="w-5 h-5" />
                      <span className="font-semibold">{match.venue_ar}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
