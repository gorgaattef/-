import { useEffect, useState } from 'react';
import { supabase, Player, Team } from '../lib/supabase';
import { Star, Users } from 'lucide-react';

type PlayerWithTeam = Player & {
  team: Team;
};

export default function StarPlayers() {
  const [players, setPlayers] = useState<PlayerWithTeam[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPlayers();
  }, []);

  async function fetchPlayers() {
    try {
      const { data: playersData, error } = await supabase
        .from('players')
        .select('*')
        .eq('is_star', true)
        .order('name_ar', { ascending: true });

      if (error) throw error;

      if (playersData && playersData.length > 0) {
        const teamIds = new Set<string>();
        playersData.forEach(player => {
          if (player.team_id) teamIds.add(player.team_id);
        });

        const { data: teamsData, error: teamsError } = await supabase
          .from('teams')
          .select('*')
          .in('id', Array.from(teamIds));

        if (teamsError) throw teamsError;

        const teamsMap = new Map(teamsData?.map(team => [team.id, team]) || []);

        const playersWithTeams = playersData.map(player => ({
          ...player,
          team: teamsMap.get(player.team_id)!,
        }));

        setPlayers(playersWithTeams);
      }
    } catch (error) {
      console.error('Error fetching players:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Star className="w-8 h-8 text-yellow-500 fill-yellow-500" />
        <h2 className="text-3xl font-bold text-gray-800">نجوم المونديال المنتظرون</h2>
      </div>

      {players.length === 0 ? (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">لا يوجد لاعبون مميزون حالياً</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {players.map((player) => (
            <div
              key={player.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all hover:-translate-y-2 cursor-pointer group"
            >
              <div className="relative">
                {player.photo_url ? (
                  <div className="h-64 overflow-hidden bg-gradient-to-b from-gray-100 to-gray-200">
                    <img
                      src={player.photo_url}
                      alt={player.name_ar}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                ) : (
                  <div className="h-64 bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                    <Users className="w-24 h-24 text-gray-400" />
                  </div>
                )}

                <div className="absolute top-3 right-3 bg-yellow-500 text-white p-2 rounded-full shadow-lg">
                  <Star className="w-5 h-5 fill-white" />
                </div>

                {player.team?.flag_url && (
                  <div className="absolute bottom-3 right-3 bg-white rounded-lg shadow-lg p-2">
                    <img
                      src={player.team.flag_url}
                      alt={player.team.name_ar}
                      className="w-12 h-8 object-cover rounded"
                    />
                  </div>
                )}
              </div>

              <div className="p-5">
                <h3 className="text-xl font-bold text-gray-800 mb-2 text-center">
                  {player.name_ar}
                </h3>

                <div className="space-y-2 text-center">
                  <div className="flex items-center justify-center gap-2 text-gray-600">
                    <span className="font-semibold text-blue-600">{player.team?.name_ar}</span>
                  </div>

                  <div className="flex items-center justify-center gap-4 text-sm text-gray-600">
                    <div className="bg-blue-50 px-3 py-1 rounded-full">
                      <span className="font-semibold">{player.position_ar}</span>
                    </div>
                    <div className="bg-gray-100 px-3 py-1 rounded-full">
                      <span className="font-semibold">{player.age} سنة</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200">
        <div className="flex items-start gap-4">
          <div className="bg-yellow-500 p-3 rounded-full">
            <Star className="w-6 h-6 text-white fill-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">نجوم المونديال</h3>
            <p className="text-gray-600 leading-relaxed">
              تعرف على أبرز اللاعبين المنتظرين في كأس العالم 2026. هؤلاء النجوم سيكونون محط الأنظار
              في البطولة وسيسعون لقيادة منتخباتهم نحو اللقب العالمي.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
