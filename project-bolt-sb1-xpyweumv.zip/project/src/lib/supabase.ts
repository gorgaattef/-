import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Team = {
  id: string;
  name: string;
  name_ar: string;
  flag_url: string;
  group_name: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goals_for: number;
  goals_against: number;
  goal_difference: number;
  points: number;
  created_at: string;
};

export type Match = {
  id: string;
  home_team_id: string;
  away_team_id: string;
  home_score: number;
  away_score: number;
  match_date: string;
  venue: string;
  venue_ar: string;
  status: 'scheduled' | 'live' | 'finished';
  group_name: string;
  stage: string;
  created_at: string;
};

export type News = {
  id: string;
  title: string;
  title_ar: string;
  content: string;
  content_ar: string;
  image_url: string;
  published_at: string;
  created_at: string;
};

export type Player = {
  id: string;
  name: string;
  name_ar: string;
  team_id: string;
  position: string;
  position_ar: string;
  photo_url: string;
  age: number;
  is_star: boolean;
  created_at: string;
};
