import { useState } from 'react';
import { Trophy } from 'lucide-react';
import NewsSection from './components/NewsSection';
import GroupStandings from './components/GroupStandings';
import UpcomingMatches from './components/UpcomingMatches';
import LiveMatches from './components/LiveMatches';
import StarPlayers from './components/StarPlayers';

function App() {
  const [activeTab, setActiveTab] = useState<'news' | 'standings' | 'upcoming' | 'live' | 'stars'>('news');

  const tabs = [
    { id: 'news' as const, label: 'آخر الأخبار' },
    { id: 'standings' as const, label: 'ترتيب المجموعات' },
    { id: 'upcoming' as const, label: 'المباريات القادمة' },
    { id: 'live' as const, label: 'نتائج مباشرة' },
    { id: 'stars' as const, label: 'نجوم المونديال' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50" dir="rtl">
      <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 text-white shadow-xl">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-center gap-4 mb-6">
            <Trophy className="w-12 h-12" />
            <div className="text-center">
              <h1 className="text-4xl font-bold mb-1">كأس العالم 2026</h1>
              <p className="text-blue-100 text-sm">الولايات المتحدة • كندا • المكسيك</p>
            </div>
            <Trophy className="w-12 h-12" />
          </div>

          <nav className="flex gap-2 overflow-x-auto pb-2 justify-center flex-wrap">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-2.5 rounded-full font-semibold transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-white text-blue-600 shadow-lg scale-105'
                    : 'bg-white/20 hover:bg-white/30 text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {activeTab === 'news' && <NewsSection />}
        {activeTab === 'standings' && <GroupStandings />}
        {activeTab === 'upcoming' && <UpcomingMatches />}
        {activeTab === 'live' && <LiveMatches />}
        {activeTab === 'stars' && <StarPlayers />}
      </main>

      <footer className="bg-gray-800 text-white py-6 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">كأس العالم FIFA 2026 © جميع الحقوق محفوظة</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
